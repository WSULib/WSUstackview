jqrotate
========

jqrotate - A jQuery rotation plugin